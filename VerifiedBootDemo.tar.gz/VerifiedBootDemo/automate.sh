#!/bin/sh
key_dir="keys"
key_name="dev_key"

MKIMG="mkimage"
DTC="/usr/bin/dtc"
CPP="/usr/bin/cpp"
OPENSSL="/usr/bin/openssl"
UBOOT_BIN="u-boot"

# Create the signing key if not present
if [ ! -d "${key_dir}" ]; then

        mkdir -p ${key_dir}

        #Generate a private signing key (RSA2048):
        $OPENSSL genrsa -F4 -out \
                "${key_dir}"/"${key_name}".key 2048
        
        # Generate a public key:
        $OPENSSL req -batch -new -x509 \
                -key "${key_dir}"/"${key_name}".key \
                -out "${key_dir}"/"${key_name}".crt
fi

FIT_ITS="vexpress.its"
OUTPUT_FIT_NAME="vexpress.itb"
OUTPUT_FIT_DIR="output-fit"
FIT_IMG="${OUTPUT_FIT_DIR}/${OUTPUT_FIT_NAME}"

rm -rf $OUTPUT_FIT_DIR; mkdir -p $OUTPUT_FIT_DIR

# Generate fitImage with space for signature:
echo "create FIT with space - no signing"
echo " --------------------------------"
DOPTS="-I dts -O dtb -p 0x1000"
$MKIMG -D "${DOPTS}" \
 -f "${FIT_ITS}" -k "${key_dir}" "${FIT_IMG}"

# Now add them and sign them
echo "Sign images with our keys"
echo " --------------------------------"
CTRL_FDT="vexpress-v2p-ca9.dtb"

$MKIMG -D "${DOPTS}" -F \
-k "${key_dir}" -K ${CTRL_FDT} -r "${FIT_IMG}"

echo "" 
echo "Adding FDT to ubootbin"

# Add FDT to Uboot, where UBOOT_BIN is the path to the raw uboot
# without the DTB automatically appended
cat ${UBOOT_BIN} ${CTRL_FDT} > ${UBOOT_BIN}-wdtb

echo "DONE -----------------------------"
