#!/bin/sh

# This script acts as a post processing utility

BOARD_DIR=$(dirname $0)
OPENSSL="$HOST_DIR/bin/openssl"
mkimage=/usr/bin/mkimage
key_name="dev_key"
FIT_IMG="smithdigital.itb"
CTRL_FDT="imx6sx-udoo-neo-basic.dtb"
UBOOT_BIN="u-boot.bin"

run() { echo "$@"; "$@"; }
die() { echo "$@" >&2; exit 1; }
test -f $BINARIES_DIR/zImage || \
	die "No kernel image found"
test -x $mkimage || \
	die "No mkimage found (host-uboot-tools has not been built?)"

#For private Signing
run $OPENSSL genrsa -F4 -out "${BINARIES_DIR}"/"${key_name}".key 2048

# Generate a public key:
run $OPENSSL req -batch -new -x509 \
		-key "${BINARIES_DIR}"/"${key_name}".key \
		-out "${BINARIES_DIR}"/"${key_name}".crt

run cp $BOARD_DIR/smithdigital.its $BINARIES_DIR/smithdigital.its || exit 1
echo "# entering $BINARIES_DIR for the next command"
(cd $BINARIES_DIR && run $mkimage -f smithdigital.its smithdigital.itb) || exit 1

DOPTS="-I dts -O dtb -p 0x1000"
(cd $BINARIES_DIR && run $mkimage -D "${DOPTS}" -F -K imx6sx-udoo-neo-basic.dtb -r smithdigital.itb) || exit 1

# Now add them and sign them
echo "Sign images with our keys"
echo " --------------------------------"

(cd $BINARIES_DIR && $mkimage -D "${DOPTS}" -F \
-k "${key_dir}" -K ${CTRL_FDT} -r "${FIT_IMG}") || exit 1

echo "" 
echo "Adding FDT to uboot"

# Add FDT to Uboot, where UBOOT is the path to the raw uboot
# without the DTB automatically appended

(cd $BINARIES_DIR && cat ${UBOOT_BIN} ${CTRL_FDT} > u-boot-wdtb.bin) || exit 1 #Appended to the end portion ( Please refer to the block diagram)

cp $BINARIES_DIR/boot.scr $TARGET_DIR/boot/boot.scr
